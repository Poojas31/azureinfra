# This is the eStore project code.
#dummy=vvs
password=navin